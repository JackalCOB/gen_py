# general_py

## Overview

General python functions usable across a multitude of different projects


## Installation and Usage

```bash
pip install git+https://github.com/JackalCOB/general_py.git
```

```python
from general_py import *
```
